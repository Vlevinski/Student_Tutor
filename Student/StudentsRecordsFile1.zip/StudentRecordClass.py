class StudentRecordClass():

    def __init__(self, fodselsNummer, firstName, lastName, age, email, programmingCourse, x ):
        self.sN =fodselsNummer,
        self.fN = firstName ,
        self.lN = lastName,
        self.age = age,
        self.email = email,
        self.pCourse = programmingCourse
        self.x = x


